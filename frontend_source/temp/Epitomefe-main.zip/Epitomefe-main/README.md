
  # Exact Figma Recreation

  This is a code bundle for Exact Figma Recreation. The original project is available at https://www.figma.com/design/AaDPiBn4rWN67ncBwNY4da/Exact-Figma-Recreation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  