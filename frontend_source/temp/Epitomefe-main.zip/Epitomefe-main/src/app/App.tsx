import CreateIdenticalDashboard from "@/imports/CreateIdenticalDashboard";

export default function App() {
  return <CreateIdenticalDashboard />;
}
