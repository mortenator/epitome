import svgPaths from "./svg-hz684oaz01";
import imgImageAllisonLipshutz from "figma:asset/a2bdfdac378ccff8474fc59a5ab45785bf625606.png";
import imgMortenatorHttpssMjRunaEaQboBj8CreateALightBlueOrbO667B05738B70432FA90276F35Df517Ae31 from "figma:asset/aacd8c263c4043b492bcaafc30e8823cc833f470.png";

function Icon() {
  return (
    <div className="h-[34.5px] relative shrink-0 w-[162.15px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 162.15 34.5">
        <g clipPath="url(#clip0_1_63)" id="Icon">
          <path d={svgPaths.p22942400} fill="var(--fill-0, #6BA4E8)" id="Vector" />
          <path d={svgPaths.p3583f600} fill="var(--fill-0, #6BA4E8)" id="Vector_2" />
          <path d={svgPaths.p38723980} fill="var(--fill-0, #6BA4E8)" id="Vector_3" />
          <path d={svgPaths.p2b548a00} fill="var(--fill-0, #6BA4E8)" id="Vector_4" />
          <path d={svgPaths.p23aef080} fill="var(--fill-0, #6BA4E8)" id="Vector_5" />
          <path d={svgPaths.p1e6243f0} fill="var(--fill-0, #6BA4E8)" id="Vector_6" />
          <path d={svgPaths.p1cf3c600} fill="var(--fill-0, #6BA4E8)" id="Vector_7" />
        </g>
        <defs>
          <clipPath id="clip0_1_63">
            <rect fill="white" height="34.5" width="162.15" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex h-[81.82px] items-center pl-[23.377px] pr-0 py-0 relative shrink-0" data-name="Container">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[26.299px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-[12.5%] left-[37.5%] right-[37.5%] top-1/2" data-name="Vector">
        <div className="absolute inset-[-11.11%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.76647 12.0539">
            <path d={svgPaths.p1b40bec0} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.34%_12.5%_12.5%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-5.26%_-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.9162 23.0114">
            <path d={svgPaths.p38b7f8c0} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="relative shrink-0 size-[26.299px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="flex-[1_0_0] h-[29.222px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[#99a1af] text-[20.455px] top-[0.73px] tracking-[-0.2197px] whitespace-pre">Home</p>
      </div>
    </div>
  );
}

function NavItem() {
  return (
    <div className="bg-[rgba(255,255,255,0)] h-[46.754px] relative rounded-[5.844px] shrink-0 w-full" data-name="NavItem">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center px-[11.689px] py-0 relative size-full">
          <Text />
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[26.299px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.34%_8.32%_8.32%_8.34%]" data-name="Vector">
        <div className="absolute inset-[-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.1099 24.1099">
            <path d={svgPaths.p16228b80} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[29.17%_29.17%_58.33%_58.33%]" data-name="Vector">
        <div className="absolute inset-[-33.33%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.47904 5.47904">
            <path d={svgPaths.p2c6d5600} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[58.33%] left-[20.83%] right-[79.17%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-25%_-1.1px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.19162 6.57485">
            <path d="M1.09581 1.09581V5.47904" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-1/4 left-[79.17%] right-[20.83%] top-[58.33%]" data-name="Vector">
        <div className="absolute inset-[-25%_-1.1px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.19162 6.57485">
            <path d="M1.09581 1.09581V5.47904" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_58.33%_83.33%_41.67%]" data-name="Vector">
        <div className="absolute inset-[-50%_-1.1px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.19162 4.38323">
            <path d="M1.09581 1.09581V3.28743" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[33.33%_70.83%_66.67%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-1.1px_-25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.57485 2.19162">
            <path d="M5.47904 1.09581H1.09581" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[66.67%_12.5%_33.33%_70.83%]" data-name="Vector">
        <div className="absolute inset-[-1.1px_-25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.57485 2.19162">
            <path d="M5.47904 1.09581H1.09581" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_54.17%_87.5%_37.5%]" data-name="Vector">
        <div className="absolute inset-[-1.1px_-50%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4.38323 2.19162">
            <path d="M3.28743 1.09581H1.09581" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="relative shrink-0 size-[26.299px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="flex-[1_0_0] h-[29.222px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[#0a0a0a] text-[20.455px] top-[0.73px] tracking-[-0.2197px] whitespace-pre">Crew list builder</p>
      </div>
    </div>
  );
}

function NavItem1() {
  return (
    <div className="bg-white h-[46.754px] relative rounded-[5.844px] shrink-0 w-full" data-name="NavItem">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center px-[11.689px] py-0 relative size-full">
          <Text2 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="h-[26.299px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[62.5%_33.33%_12.5%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-16.67%_-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.5329 8.76647">
            <path d={svgPaths.p19d1bc00} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[12.5%_45.83%_54.17%_20.83%]" data-name="Vector">
        <div className="absolute inset-[-12.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9581 10.9581">
            <path d={svgPaths.p3ae3b080} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[63.04%_8.33%_12.5%_79.17%]" data-name="Vector">
        <div className="absolute inset-[-17.04%_-33.33%_-17.04%_-33.34%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.47931 8.62428">
            <path d={svgPaths.p266ae300} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[13.04%_20.8%_54.67%_66.67%]" data-name="Vector">
        <div className="absolute inset-[-12.91%_-33.25%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.4879 10.6847">
            <path d={svgPaths.p28599a00} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="relative shrink-0 size-[26.299px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Text5() {
  return (
    <div className="flex-[1_0_0] h-[29.222px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[#9a9ca0] text-[20.455px] top-[0.73px] tracking-[-0.2197px] whitespace-pre">Crew</p>
      </div>
    </div>
  );
}

function NavItem2() {
  return (
    <div className="h-[46.754px] relative rounded-[5.844px] shrink-0 w-full" data-name="NavItem">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center px-[11.689px] py-0 relative size-full">
          <Text4 />
          <Text5 />
        </div>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="h-[26.299px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[12.5%_8.33%_16.67%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-5.88%_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.1078 20.8204">
            <path d={svgPaths.p37b34580} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[41.67%_8.33%_58.33%_8.33%]" data-name="Vector">
        <div className="absolute inset-[-1.1px_-5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.1078 2.19162">
            <path d="M1.09581 1.09581H23.012" id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="relative shrink-0 size-[26.299px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="flex-[1_0_0] h-[29.222px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[#9a9ca0] text-[20.455px] top-[0.73px] tracking-[-0.2197px] whitespace-pre">Projects</p>
      </div>
    </div>
  );
}

function NavItem3() {
  return (
    <div className="h-[46.754px] relative rounded-[5.844px] shrink-0 w-full" data-name="NavItem">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center px-[11.689px] py-0 relative size-full">
          <Text6 />
          <Text7 />
        </div>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="h-[26.299px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[87.5%_42.78%_8.33%_42.78%]" data-name="Vector">
        <div className="absolute inset-[-100.03%_-28.87%_-100.01%_-28.87%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.98786 3.28751">
            <path d={svgPaths.p20aab680} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[8.33%_12.5%_29.17%_12.5%]" data-name="Vector">
        <div className="absolute inset-[-6.67%_-5.56%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.9158 18.6287">
            <path d={svgPaths.p1d72e280} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text8() {
  return (
    <div className="relative shrink-0 size-[26.299px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon5 />
      </div>
    </div>
  );
}

function Text9() {
  return (
    <div className="flex-[1_0_0] h-[29.222px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[#9a9ca0] text-[20.455px] top-[0.73px] tracking-[-0.2197px] whitespace-pre">Notifications</p>
      </div>
    </div>
  );
}

function Text10() {
  return (
    <div className="bg-[#101828] relative rounded-[24512794px] shrink-0 size-[29.222px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Medium',sans-serif] font-medium leading-[23.377px] not-italic relative shrink-0 text-[17.533px] text-center text-white whitespace-pre">6</p>
      </div>
    </div>
  );
}

function NavItem4() {
  return (
    <div className="h-[46.754px] relative rounded-[5.844px] shrink-0 w-full" data-name="NavItem">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center px-[11.689px] py-0 relative size-full">
          <Text8 />
          <Text9 />
          <Text10 />
        </div>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="h-[26.299px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[8.33%_12.43%]" data-name="Vector">
        <div className="absolute inset-[-5%_-5.54%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.9547 24.1078">
            <path d={svgPaths.peeac800} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[37.5%]" data-name="Vector">
        <div className="absolute inset-[-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.76647 8.76647">
            <path d={svgPaths.p369f57f0} id="Vector" stroke="var(--stroke-0, #9A9CA0)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.19162" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text11() {
  return (
    <div className="relative shrink-0 size-[26.299px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Icon6 />
      </div>
    </div>
  );
}

function Text12() {
  return (
    <div className="flex-[1_0_0] h-[29.222px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[#9a9ca0] text-[20.455px] top-[0.73px] tracking-[-0.2197px] whitespace-pre">Settings</p>
      </div>
    </div>
  );
}

function NavItem5() {
  return (
    <div className="h-[46.754px] relative rounded-[5.844px] shrink-0 w-full" data-name="NavItem">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center px-[11.689px] py-0 relative size-full">
          <Text11 />
          <Text12 />
        </div>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Container">
      <NavItem />
      <NavItem1 />
      <NavItem2 />
      <NavItem3 />
      <NavItem4 />
      <NavItem5 />
    </div>
  );
}

function Navigation() {
  return (
    <div className="relative shrink-0 w-full" data-name="Navigation">
      <div className="content-stretch flex flex-col items-start px-[11.689px] py-0 relative w-full">
        <Container1 />
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <Container />
      <Navigation />
    </div>
  );
}

function ImageAllisonLipshutz() {
  return (
    <div className="relative rounded-[24512794px] shrink-0 size-[46.754px]" data-name="Image (Allison Lipshutz)">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none rounded-[24512794px] size-full" src={imgImageAllisonLipshutz} />
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[29.222px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-0 not-italic text-[20.455px] text-white top-[0.73px] tracking-[-0.2197px] w-[153.413px] whitespace-pre-wrap">Allison Lipshutz</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[23.377px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[23.377px] left-0 not-italic text-[17.533px] text-[rgba(255,255,255,0.5)] top-[1.46px] whitespace-pre">Producer</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="flex-[1_0_0] h-[52.599px] min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container2 />
        <Container3 />
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex gap-[11.689px] h-[52.599px] items-center relative shrink-0 w-full" data-name="Container">
      <ImageAllisonLipshutz />
      <Container4 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[23.377px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.3772 23.3772">
        <g id="Icon">
          <path d={svgPaths.p3b7f4a80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.9481" />
          <path d="M19.4811 2.92215V6.81836" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.9481" />
          <path d="M21.4291 4.87025H17.5329" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.9481" />
          <path d="M3.89614 16.5589V18.507" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.9481" />
          <path d="M4.87025 17.5329H2.92214" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.9481" />
        </g>
      </svg>
    </div>
  );
}

function Text13() {
  return (
    <div className="h-[29.222px] relative shrink-0 w-[131.782px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.222px] left-[66px] not-italic text-[20.455px] text-center text-white top-[0.73px] tracking-[-0.2197px] translate-x-[-50%] whitespace-pre">Upgrade Now</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="backdrop-blur-[2px] backdrop-filter bg-[rgba(255,255,255,0.2)] h-[52.599px] relative rounded-[14.611px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex gap-[11.689px] items-center justify-center pl-0 pr-[0.011px] py-0 relative size-full">
          <Icon7 />
          <Text13 />
        </div>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] items-start left-[17px] top-[34px] w-[289.934px]">
      <Container5 />
      <Button />
    </div>
  );
}

function Frame6() {
  return (
    <div className="h-[197px] overflow-clip relative rounded-[10px] shrink-0 w-[325px]">
      <div className="absolute h-[197px] left-0 top-0 w-[325px]" style={{ backgroundImage: "linear-gradient(rgb(82, 159, 237) 0%, rgb(85, 162, 237) 61.538%, rgb(117, 189, 245) 84.135%, rgb(217, 243, 255) 100%)" }} />
      <Frame5 />
    </div>
  );
}

function LeftSidebar() {
  return (
    <div className="bg-[#eff4f8] h-full relative shrink-0 w-[357px]" data-name="LeftSidebar">
      <div aria-hidden="true" className="absolute border-[#eff4f8] border-[0px_1.461px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-between p-[16px] relative size-full">
        <Frame4 />
        <Frame6 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full" data-name="Heading 1">
      <p className="font-['Inter_Tight:Regular',sans-serif] font-normal leading-[58.443px] relative shrink-0 text-[#101828] text-[52.599px] tracking-[0.5393px] whitespace-pre">Welcome, Allison!</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="Paragraph">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[35.066px] not-italic relative shrink-0 text-[#4a5565] text-[23.377px] tracking-[-0.4566px] whitespace-pre">How can I help you today?</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[29px] items-center relative shrink-0 w-[461px]">
      <div className="relative rounded-[99999px] shadow-[0px_4px_10px_5px_rgba(43,127,255,0.1)] shrink-0 size-[116px]" data-name="mortenator_httpss.mj.runaEA__QBOBj8_Create_a_light_blue_orb_o_667b0573-8b70-432f-a902-76f35df517ae_3 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[99999px]">
          <img alt="" className="absolute h-[176%] left-[-16.07%] max-w-none top-[-37.33%] w-[132.57%]" src={imgMortenatorHttpssMjRunaEaQboBj8CreateALightBlueOrbO667B05738B70432FA90276F35Df517Ae31} />
        </div>
      </div>
      <Heading />
      <Paragraph />
    </div>
  );
}

function Icon8() {
  return (
    <div className="h-[64px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[67.19%_7.03%_7.81%_17.97%]" data-name="Vector">
        <div className="absolute inset-[-12.5%_-4.17%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 20">
            <path d={svgPaths.p20f36b80} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[17.19%_23.7%_61.98%_34.64%]" data-name="Vector">
        <div className="absolute inset-[-15%_-7.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30.6667 17.3333">
            <path d={svgPaths.p33ef660} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[17.19%_44.53%_32.81%_55.47%]" data-name="Vector">
        <div className="absolute inset-[-6.25%_-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4 36">
            <path d="M2 2V34" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 size-[64px]" data-name="Container">
      <Icon8 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Paragraph">
      <div className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-[156px] not-italic text-[#99a1af] text-[20px] text-center top-[3px] tracking-[-0.4492px] translate-x-[-50%] whitespace-nowrap whitespace-pre">
        <p className="mb-0">Drop your crew list for a call sheet</p>
        <p>or, describe your shoot</p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[303.398px]" data-name="Container">
      <Paragraph1 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-center relative">
        <Container6 />
        <Container7 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="bg-gradient-to-t content-stretch flex flex-col from-[#f9fafb] h-[279px] items-center justify-center relative shrink-0 to-[61.538%] to-[rgba(255,255,255,0)] w-full" data-name="Container">
      <Frame3 />
    </div>
  );
}

function TextArea() {
  return (
    <div className="content-stretch flex h-[60px] items-start overflow-clip relative shrink-0 w-[696px]" data-name="Text Area">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[28px] not-italic relative shrink-0 text-[#99a1af] text-[18px] tracking-[-0.4395px] whitespace-pre">Describe your shoot here...</p>
    </div>
  );
}

function Icon9() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/2 left-[20.83%] right-[20.83%] top-[20.83%]" data-name="Vector">
        <div className="absolute inset-[-14.29%_-7.14%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 7.5">
            <path d={svgPaths.p15642080} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          </svg>
        </div>
      </div>
      <div className="absolute bottom-[20.83%] left-1/2 right-1/2 top-[20.83%]" data-name="Vector">
        <div className="absolute inset-[-7.14%_-0.83px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.66667 13.3333">
            <path d="M0.833333 12.5V0.833333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#d1d5dc] relative rounded-[16777200px] shrink-0 size-[44px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[12px] px-[12px] relative size-full">
        <Icon9 />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex h-[44px] items-end justify-end relative shrink-0 w-full" data-name="Container">
      <Button1 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[720px]">
      <TextArea />
      <Container9 />
    </div>
  );
}

function Container10() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[16px] items-center pb-[10px] pt-px px-px relative rounded-[24px] shrink-0 w-[769px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-4 border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[24px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
      <Container8 />
      <Frame />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col gap-[81px] h-[932px] items-center justify-center relative shrink-0 w-full">
      <Frame1 />
      <Container10 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="bg-[rgba(0,0,0,0)] flex-[1_0_0] h-[1143.329px] min-h-px min-w-px relative" data-name="MainContent">
      <div className="flex flex-col items-center justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center px-[47px] py-0 relative size-full">
          <Frame2 />
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="bg-[#f9fafb] content-stretch flex h-[1220px] items-start overflow-clip relative shrink-0 w-full" data-name="App">
      <LeftSidebar />
      <MainContent />
    </div>
  );
}

export default function CreateIdenticalDashboard() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Create Identical Dashboard">
      <App />
    </div>
  );
}